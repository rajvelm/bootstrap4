import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-box',
  templateUrl: './theme-box.component.html',
  styleUrls: ['./theme-box.component.scss']
})
export class ThemeBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
