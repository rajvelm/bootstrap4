import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cp-history',
  templateUrl: './cp-history.component.html',
  styleUrls: ['./cp-history.component.scss']
})
export class CpHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
