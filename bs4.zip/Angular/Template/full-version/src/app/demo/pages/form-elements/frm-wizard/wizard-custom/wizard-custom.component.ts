import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-custom',
  templateUrl: './wizard-custom.component.html',
  styleUrls: ['./wizard-custom.component.scss']
})
export class WizardCustomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
