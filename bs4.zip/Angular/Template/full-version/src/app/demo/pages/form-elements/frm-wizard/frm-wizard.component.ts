import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frm-wizard',
  templateUrl: './frm-wizard.component.html',
  styleUrls: ['./frm-wizard.component.scss']
})
export class FrmWizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
