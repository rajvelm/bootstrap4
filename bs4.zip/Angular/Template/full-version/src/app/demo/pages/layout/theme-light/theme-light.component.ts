import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-light',
  templateUrl: './theme-light.component.html',
  styleUrls: ['./theme-light.component.scss']
})
export class ThemeLightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
