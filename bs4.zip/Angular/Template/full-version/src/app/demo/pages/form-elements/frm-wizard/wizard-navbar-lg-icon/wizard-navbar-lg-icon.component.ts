import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-navbar-lg-icon',
  templateUrl: './wizard-navbar-lg-icon.component.html',
  styleUrls: ['./wizard-navbar-lg-icon.component.scss']
})
export class WizardNavbarLgIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
