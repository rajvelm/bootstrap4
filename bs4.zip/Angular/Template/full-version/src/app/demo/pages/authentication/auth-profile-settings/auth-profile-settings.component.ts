import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-profile-settings',
  templateUrl: './auth-profile-settings.component.html',
  styleUrls: ['./auth-profile-settings.component.scss']
})
export class AuthProfileSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
