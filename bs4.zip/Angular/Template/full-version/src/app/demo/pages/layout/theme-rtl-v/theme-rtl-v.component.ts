import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-rtl-v',
  templateUrl: './theme-rtl-v.component.html',
  styleUrls: ['./theme-rtl-v.component.scss']
})
export class ThemeRtlVComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
