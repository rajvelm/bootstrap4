import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery-masonry',
  templateUrl: './gallery-masonry.component.html',
  styleUrls: ['./gallery-masonry.component.scss']
})
export class GalleryMasonryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
