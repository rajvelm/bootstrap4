import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-collapse-menu',
  templateUrl: './theme-collapse-menu.component.html',
  styleUrls: ['./theme-collapse-menu.component.scss']
})
export class ThemeCollapseMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
