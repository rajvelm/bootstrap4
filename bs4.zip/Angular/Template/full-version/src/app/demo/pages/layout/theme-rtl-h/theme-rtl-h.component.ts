import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-rtl-h',
  templateUrl: './theme-rtl-h.component.html',
  styleUrls: ['./theme-rtl-h.component.scss']
})
export class ThemeRtlHComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
